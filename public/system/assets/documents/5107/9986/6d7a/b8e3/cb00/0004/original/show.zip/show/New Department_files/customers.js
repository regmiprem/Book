(function() {

  jQuery(function() {
    return $('#customer_plan_tokens').tokenInput('/plans.json', {
      theme: 'facebook',
      prePopulate: $('#customer_plan_tokens').data('load')
    });
  });

}).call(this);
