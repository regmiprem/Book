var checked=false;
var frmname='';
function checkedAll(frmname){
	 var valus= document.getElementById(frmname);
	 if (checked==false)
		 {
			 checked=true;
		 }
	 else
		 {
			 checked = false;
		 }
	 for (var i =0; i < valus.elements.length; i++)
		 {
			 valus.elements[i].checked=checked;
		 }
}

function checkCheckBoxes() {	
	var elems=document.getElementById('form1').elements.length;
	var str='';
	 for(i=0; i<elems; i++)
	 	if (document.getElementById('form1').elements[i].id=='check_box_id_' && document.getElementById('form1').elements[i].checked)
		 	str+=document.getElementById('form1').elements[i].value+',';
	if(str==''){
		alert('Please first select the records');
		return false;
	}
	if(confirm('Are you sure?')==true){
		return true;
	}
	else return false;
}

;
