(function() {

  jQuery(function() {
    return $('#asset_tag_tokens').tokenInput('/tags.json', {
      theme: 'facebook',
      prePopulate: $('#asset_tag_tokens').data('load')
    });
  });

}).call(this);
