// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or vendor/assets/javascripts of plugins, if any, can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// the compiled file.
//
// WARNING: THE FIRST BLANK LINE MARKS THE END OF WHAT'S TO BE PROCESSED, ANY BLANK LINE SHOULD
// GO AFTER THE REQUIRES BELOW.
//





//= require_sel




$(function() {
		$( '.dp1' ).datepicker({
			changeMonth: true,
			changeYear: true,
			showButtonPanel: true
		});
		$( '.from' ).datepicker({
			defaultDate: "+1w",
			changeMonth: true,
			changeYear: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				$( '.to' ).datepicker( "option", "minDate", selectedDate );
				if($(this).hasClass('calc'))
					updateTotal();
					
			}
		});
		$( '.to' ).datepicker({
			defaultDate: "+1w",
			changeMonth: true,
			changeYear: true,
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				$( '.from' ).datepicker( "option", "maxDate", selectedDate );
				if($(this).hasClass('calc'))
					updateTotal();
			}
		});
		$('.datepicker').datepicker({
			 "dateFormat":"'day' d 'of' MM 'in the year' yy"
		});
		$("#employee_registers th a").live("click", function() {
          $.getScript(this.href);
        return false;
         });
       $("#employee_registers_search input").keyup(function() {
       $.get($("#employee_registers_search").attr("action"), $("#employee_registers_search").serialize(), null, "script");
       return false;
  });

		
		
	});

