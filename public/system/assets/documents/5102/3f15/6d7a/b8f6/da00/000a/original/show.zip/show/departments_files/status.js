/*

Publish Status - 1.0 - for publish or not for gobingoo ci 
(c) 2012 Narendra Maharjan

*/


$(document).ready(function(){
	//START FOR TRUE OR FALSE DATA
	//Eg. publish data yes or no,searchable  yes or no
	$('.btn-group .btn').live('click',function(){
		var val = $(this).val();
		var attr_id = $(this).attr('id');
		var parts_id= attr_id.split('_');
		var length_id = parts_id.length;
		var values=parts_id[length_id-1];
		var newvalues=$.trim(values);
		var new_parts_name = parts_id.splice(0,length_id-1).join('_');
		if(newvalues == 'yes' ){
				
				$(this).addClass('btn-success');
				$('#'+new_parts_name+'_no').removeClass('btn-danger');
				$('#'+new_parts_name).val(val);
				$(".profile_img").show();
				
		}else{
				
				$(this).addClass('btn-danger');
				$('#'+new_parts_name+'_yes').removeClass('btn-success');
				$('#'+new_parts_name).val(val);
				$(".profile_img").hide();
		}
		
	});
	//END FOR TRUE OR FALSE DATA
	
});
