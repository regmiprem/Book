(function() {

  jQuery(function() {
    return $('#employee_asset_lend_asset_tokens').tokenInput('/assets.json', {
      theme: 'facebook',
      prePopulate: $('#employee_asset_lend_asset_tokens').data('load')
    });
  });

}).call(this);
